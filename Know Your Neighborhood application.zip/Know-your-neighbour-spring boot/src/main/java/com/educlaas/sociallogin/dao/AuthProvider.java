package com.educlaas.sociallogin.dao;

public enum AuthProvider {
	google,
	facebook,
	local
}
