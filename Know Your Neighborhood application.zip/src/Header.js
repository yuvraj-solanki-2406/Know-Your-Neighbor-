import './Header.css';
function Header(){
    return(
        <div className="header">
            <h1> This is Header Component !</h1>
        </div>

    );
}
export default Header