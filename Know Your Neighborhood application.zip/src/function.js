// export default function timesTwo(a){
//     return a*2;
// }

export default function Star(){
    return <h1>Cool Text</h1>
}
